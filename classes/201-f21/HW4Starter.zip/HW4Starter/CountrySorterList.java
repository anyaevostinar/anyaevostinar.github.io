import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

public class CountrySorterList {
    Node firstNode;
    String indicator;
    private class Node {
        private Country    data; 
        private Node next; 
    
        private Node(Country dataPortion) {
            this(dataPortion, null);
        } // end constructor

        private Node(Country dataPortion, Node nextNode) {
            data = dataPortion;
            next = nextNode;
        } // end constructor
    } // end Node

    public CountrySorterList(String ind, String filename) {
        indicator = ind;
        File inputFile = new File(filename);
        Scanner scanner = null;
        try {
          scanner = new Scanner(inputFile);
        } catch (FileNotFoundException e) {
          System.err.println(e);
          System.exit(1);
        }
        scanner.nextLine();
        while (scanner.hasNextLine()) {
          Country newCountry = new Country(scanner.nextLine());
        }
        scanner.close();
      }


    



    public static void main(String[] args) {

    }

}
