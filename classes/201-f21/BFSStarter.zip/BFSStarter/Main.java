import java.util.*;

class Main {



  public static void main(String[] args) {
    UnweightedGraph test = new MysteryUnweightedGraphImplementation(false, 4);
    test.addEdge(0, 3);
    test.addEdge(1, 3);
    test.addEdge(3, 2);
    test.addEdge(1, 2);

  }
}