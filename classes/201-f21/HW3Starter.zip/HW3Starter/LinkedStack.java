
/**
* Insert Documentation here!
*
*/
public class LinkedStack<T> implements Stack<T> {
    /**
     * Adds an item to the top of this stack.
     * @param item The item to add.
     */
    public void push(T item) {

    }
    
    /**
     * Removes and returns the item from the top of this stack.
     * @return the item at the top of the stack. Returns null if empty.
     */
    public T pop() {
        return null;
    }
    
    /**
     * Returns the item on top of the stack, without removing it.
     * @return the item at the top of the stack. Returns null if empty.
     */
    public T peek() {
        return null;
    }
    
    /** 
     * Returns whether the stack is empty. 
     * @return true if the stack is empty; false otherwise
     */
    public boolean isEmpty() {
        return false;
    }
    
    /** 
     * Removes all items from the stack. 
     */
    public void clear() {

    }
    
}
