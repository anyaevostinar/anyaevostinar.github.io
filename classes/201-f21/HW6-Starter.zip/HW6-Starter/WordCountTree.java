import java.util.*;

public class WordCountTree {
  Node root;

  private class Node {
    char character;
    int count;
    List<Node> children = new LinkedList<Node>();

    public Node(char ch, int in){
      character = ch;
      count = in;
    }

    public Node() {
      count = 0;
    }
  }
        
  public WordCountTree(){

  }
  

  public void incrementCount(String word){

  }
  

  public boolean contains(String word){
    return false;
  }
  

  public int getCount(String word){
    return 0;
  }

  public int getNodeCount(){
    return 0;
  }
  
  /** 
  * Creates and sorts in decreasing order a list 
  * of WordCount objects, one per word stored in this 
  * WordCountTree.
  *
  * @return      a List of WordCount objects in decreasing order
  */
  public List<WordCount> getWordCountsByCount(){
    List<WordCount> wordCountList = new ArrayList<WordCount>();
    getWordCountsHelper(root, "", wordCountList);
    Collections.sort(wordCountList, new SortWordCount());
    return wordCountList;
  }

  private void getWordCountsHelper(Node node, String wordSoFar, List<WordCount> wordCountList) {
    if(node.children.size() == 0) {
      return;
    }
    for(Node child : node.children) {
      String nextWord = wordSoFar + child.character;

      if(child.count != 0) {
        WordCount newWord = new WordCount(nextWord, child.count);
        wordCountList.add(newWord);
      }

      getWordCountsHelper(child, nextWord, wordCountList);
    }
  }

  public static void main(String[] args) {
    //Tests for your methods here!
  }

}