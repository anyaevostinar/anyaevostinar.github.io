public class Flashcard implements Comparable<Flashcard>{
  
  /**
   * Creates a new flashcard with the given
   * priority level, text for the front of the card (front),
   * and text for the back of the card (back).
   */
  public Flashcard(Integer priority, String front, String back){

  }

  /**
   * Gets the text for the front of this flashcard.
   */
  public String getFrontText(){
    return null;
  }
  
  /**
   * Gets the text for the Back of this flashcard.
   */
  public String getBackText(){
    return null;
  }
  
  /**
   * Gets the priority level of this flashcard.
   */
  public Integer getPriority(){
    return null;
  }

  /**
   * Compares the priority levels of the current flashcard and another flashcard
   */
  public int compareTo(Flashcard b){
    return 0;
  }

  /**
   * Returns a string in the format "priority,front,back\n"
   */
  public String toString() {
    return null;
  }

  /**
   * Updates the priority of the card but doesn't allow priority to become negative.
   */
  public void setPriority(Integer newPriority){

  }

    
}