import java.util.*;


public class FlashcardPQ implements PriorityQueue<Flashcard> {
  

  
   /** Adds the given item to the queue. */
    public void add(Flashcard item){
      
    }

    
    
    /** Removes the first item according to compareTo from the queue, and returns it.
     * Returns null if the queue is empty.
     */
    public Flashcard poll(){
      return null;
    }
    
    /** Returns the first item according to compareTo in the queue, without removing it.
     * Returns null if the queue is empty.
     */
    public Flashcard peek(){
      return null;
    }
    
    /** Returns true if the queue is empty. */
    public boolean isEmpty(){
      return false;
    }
    
    /** Removes all items from the queue. */
    public void clear(){
      
    }

    /**
     * Creates a String of the priority queue to save to the file in the correct format
     * @return a string to save to a file
     */
    public String toString() {
      return null;
    }


    public static void main(String[] args) {
      
    }
}