import java.util.*;
import java.io.*;

public class FlashcardDisplayer {
    FlashcardPQ cards = new FlashcardPQ();
    String fileName;

    /**
     * Creates a FlashcardDisplayer with the flashcards in file. 
     * File has one flashcard per line. Each line is formatted as:
     * priority,front,back
     * @param inputFile The file with the flashcards saved
     */
    public FlashcardDisplayer(String inputFile) {
        fileName = inputFile;
        File input = new File(inputFile);
        Scanner scanner = null;
        try {
            scanner = new Scanner(input);
        } catch (FileNotFoundException e) {
            System.err.println(e);
            System.exit(1);
        }

        while(scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] splitline = line.split(",");
            cards.add(new Flashcard(Integer.parseInt(splitline[0]), splitline[1], splitline[2]));
        }
        scanner.close();
    }
    
    /**
     * Writes out all flashcards to the same file
     * they were read from so that they can be loaded by
     * the FlashcardDisplayer(String file) constructor. 
     * The FlashcardDisplayer will still have 
     * all the same flashcards after this method is called 
     * as it did before the method was called.
     */
    public void saveFlashcards() {
        try {
            FileWriter myWriter = new FileWriter(fileName);
            myWriter.write(cards.toString());
            myWriter.close();
        } catch (IOException e) {
            System.err.println(e);
            System.exit(1);
        }
    }

    /**
     * Continuously displays flashcards to the user
    * and checks their answers, updating the priority
    * of each flashcard based on if the user answered 
    * correctly or not. Displays the highest priority
    * flashcard first. Ends when the user enters 'save'.
    */
    public void displayFlashcards(){

    }

    public static void main(String[] args) {
        
    }
}
