/**
 * Garden is a simulation of an actual garden that instantiates plants, waters them,
 * and displays them. (Add details if you change things about the class)
 * Look at the lab description for details about what to do with the Garden class.
 */
public class Garden {

    
    
    public static void main(String[] args) {
    	
    }
}
