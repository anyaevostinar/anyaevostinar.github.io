Intro to C #2: minigrep
CS208 Intro to Computer Systems
5 January 2024

This is your second homework assignment package for this course.
Here's a very brief description of how to use the Makefile and
test data provided in this package.

To build minigrep:
- Write your C program in minigrep.c
- Run "make minigrep"
- If your program compiles properly, the executable file
    minigrep will appear

To run the one tiny test of minigrep provided in this package:
- Run "make test"

Just running "make" will both build and test minigrep.
