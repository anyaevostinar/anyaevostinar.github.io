#include <stdio.h>

#include "call_proc.h"

void proc(long  x1, long  *p1,
          int   x2, int   *p2,
          short x3, short *p3,
          char  x4, char  *p4)
{
    *p1 += x1;
    *p2 += x2;
    *p3 += x3;
    *p4 += x4;
}

long call_proc(long n)
{
    long  a = 1;
    int   b = 2;
    short c = 3;
    char  d = 4;

    proc(10, &a, 20, &b, 30, &c, 40, &d);

    return (a+b) * (c-d) + n;
}

void trigger_alarm()
{
    printf("Nope!\n");
    exit(1);
}

// This program gets user input and pass it to phase_0.
int main()
{
    char buf[100];
    char *input;

    printf("Guess a number: ");

    input = fgets(buf, 100, stdin);
    phase_0(input); // defined elsewhere

    return 0;
}