Intro to C #1: select-column
CS208 Intro to Computer Systems
3 January 2024

This is your first homework assignment package for this course.
Here's a very brief description of how to use the Makefile and
test data provided in this package.

To build select-column:
- Write your C program in select-column.c
- Run "make select-column"
- If your program compiles properly, the executable file
    select-column will appear

To run the one tiny test of select-column provided in this package:
- Run "make test"

For your convenience, just running "make" will both build and test
select-column.
