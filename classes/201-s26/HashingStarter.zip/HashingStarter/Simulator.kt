import Package
import ShippingTracker
import java.io.File 
import java.io.FileNotFoundException
import kotlin.system.exitProcess

//TODO: It turns out you can't remove things from a MutableList while iterating through it, so our test simulator doesn't work, I guess we'll just see how the full deployment goes instead!

class LogisticsSimulator {

    var tracker = ShippingTracker()

    /**
     * Simulates a package moving through different checkpoints.
     */
    fun movePackage(pkg: Package, checkpoint: Pair<Double, Double>, status: String = "In Transit") {
        pkg.updateLocation(checkpoint.first, checkpoint.second, "Passed through checkpoint")
        pkg.status = status
    }

    fun deliver(pkg: Package) {
        pkg.updateLocation(pkg.currentLat, pkg.currentLong, "Package delivered")
        pkg.status = "Delivered"
    }

    // A simple mapping of Zip to Coordinates
    private val zipDestinations = mapOf(
        10001 to Pair(40.7128, -74.0060),   // New York, NY
        90210 to Pair(34.0736, -118.4004),  // Beverly Hills, CA
        60601 to Pair(41.8818, -87.6231),   // Chicago, IL
        77001 to Pair(29.7604, -95.3698),   // Houston, TX
        33101 to Pair(25.7617, -80.1918),   // Miami, FL
        94101 to Pair(37.7749, -122.4194),  // San Francisco, CA
        30301 to Pair(33.7490, -84.3880),   // Atlanta, GA
        2101  to Pair(42.3601, -71.0589),   // Boston, MA (Note: Leading zero omitted)
        98101 to Pair(47.6062, -122.3321),  // Seattle, WA
        80201 to Pair(39.7392, -104.9903)   // Denver, CO
    )

    private fun moveTowardDestination(pkg: Package) {
        val target = zipDestinations[pkg.destinationZip] ?: return
        
        // Nudge the package 0.1 degrees closer to the target
        val newLat = if (pkg.currentLat < target.first) pkg.currentLat + 0.1 else pkg.currentLat - 0.1
        val newLong = if (pkg.currentLong < target.second) pkg.currentLong + 0.1 else pkg.currentLong - 0.1
        
        pkg.updateLocation(newLat, newLong, "In Transit")
    }

    /** 
    * Setup the logistics simulator with some initial packages and checkpoints.
    */
    fun setup() {
        val wareHouseLat = 41.7128
        val wareHouseLong = -75.0065

        // Read from the packageData.csv file and create packages
        val inputFilePath: String = "packageData.csv"
        val inputFile: File = File(inputFilePath)

        try {
            inputFile.forEachLine() {
                val parts = it.split(",")
                if (parts.size == 3 && parts[0] != "tracking_id") {
                    println("Creating package with data: ${parts[0]}, ${parts[1]}, ${parts[2]}")
                    val trackingId = parts[0].trim()
                    val zipCode = parts[1].trim().toInt()
                    val weight = parts[2].trim().toDouble()
                    val pkg = Package(trackingId, zipCode, wareHouseLat, wareHouseLong, weight)
                    tracker.add(pkg)
                }
            }
        } catch (e: Exception) {
            println("Error reading package data: ${e.message}")
        }
    }

    fun isAtDestination(pkg: Package): Boolean {
        val target = zipDestinations[pkg.destinationZip] ?: return false
        val latDiff = Math.abs(pkg.currentLat - target.first)
        val longDiff = Math.abs(pkg.currentLong - target.second)
        return latDiff < 0.1 && longDiff < 0.1 // Consider it "at destination" if within 0.1 degrees
    }

    fun simulateStep() {
        // Get a snapshot of all packages currently in the system
        val allPackages = tracker.getAllPackages() 


        for (pkg in allPackages) {
            moveTowardDestination(pkg)

            val found = tracker.find(pkg.trackingID, pkg.destinationZip)
            
            if (found == null) {
                println("CRITICAL ERROR: Package ${pkg.trackingID} lost in the void!")
                println("It is still in the system, but the Hash Table can't find it.")
                println("Check if your hashCode() uses mutable fields like currentLat!")
                return // Stop the simulation so they can debug
            }

            if (isAtDestination(pkg)) {
                deliver(pkg)
                tracker.remove(pkg)
                println("Removed ${pkg.trackingID} from tracker after delivery.")
            }
        }
    }

    fun finalState() {
        println("Final state of all packages:")
        for (pkg in tracker.getAllPackages()) {
            println(pkg)
        }
    }

}

fun main() {
    val tracker = ShippingTracker()
    val simulator = LogisticsSimulator()

    simulator.setup()

    for (step in 1..20) {
        simulator.simulateStep()
    }

    simulator.finalState()

}