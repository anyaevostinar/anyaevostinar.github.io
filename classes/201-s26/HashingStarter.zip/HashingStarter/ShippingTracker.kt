import Package
import LinkedUnorderedList
import Node

class ShippingTracker {
    val packages = mutableListOf<Package>()

    // TODO: Use these?
    private val buckets: Array<LinkedUnorderedList<Package>?> = arrayOfNulls(5000)
    var tableSize = buckets.size

    // Compresses the hash code to fit within the bounds of the table size, ensuring a non-negative index, according to the intern
    fun compressToSize(hashCode: Int) : Int {
        var compressedValue = hashCode % tableSize
        if(compressedValue >= 0) {
            return compressedValue
        } else {
            return compressedValue+tableSize
            //Mod of a negative number is negative - 
            //map back to positive so in the range of 
            //[0,tableSize)
        }
    }

    // This will get all the packages from the hash table whenever it is implemented...
    // Why did the intern start here??
    fun getAllPackages(): List<Package> {
        val allPackages = mutableListOf<Package>()
        for (bucket in buckets) {
            if (bucket != null) {
                var currentNode = bucket.head // Food for thought, how to restructure so we don't have to access the internals of LinkedUnorderedList?
                while (currentNode != null) {
                    allPackages.add(currentNode.data)
                    currentNode = currentNode.next
                }
            }
        }
        // TODO: return allPackages
        // Oops, ran out of time, for now we just return our mutable list
        return packages
    }


    // The intern didn't get to this part yet, so we had to keep using the mutableList....
    fun add(newPackage: Package) {
        val packageIndex = packages.indexOf(newPackage)
        if (packageIndex != -1) {
            // Package already exists, update the existing package's information
            val existingPackage = packages[packageIndex]
            existingPackage.currentLat = newPackage.currentLat
            existingPackage.currentLong = newPackage.currentLong
            existingPackage.status = newPackage.status
        } else {
            // Package does not exist, add it to the list
            packages.add(newPackage)
        }
    }

    // TODO: Check how bad it actually is to just loop through our list, it's so easy....
    fun find(trackingID: String, destinationZip: Int): Package? {
        for (pkg in packages) {
            if (pkg.trackingID == trackingID && pkg.destinationZip == destinationZip) {
                return pkg
            }
        }
        return null
    }

    // TODO: Again, is this really that bad?? We only have like 1000 packages a day....
    fun remove(deliveredPackage: Package) {
        packages.remove(deliveredPackage)
    }


}

fun main() {
    // How do we know if this works anyway? Just deploy it and see how many packages are lost?
}