class Package(val trackingID: String, val destinationZip: Int, var currentLat: Double, var currentLong: Double, var weight: Double, var status: String = "In Warehouse") {

    // An internal log of every location this package has visited
    private val _history = mutableListOf<String>()
    val history: List<String> get() = _history

    // This method is used to update the package's location and status as it moves through the delivery process.
    fun updateLocation(lat: Double, long: Double, note: String) {
        currentLat = lat
        currentLong = long
        status = "In Transit"
        _history.add("Location: ($lat, $long) - $note")
    }

    override fun toString(): String {
        return "Pkg[$trackingID] to $destinationZip @ ($currentLat, $currentLong) - $status"
    }

    override fun equals(other: Any?): Boolean {
        if (other === this) {
            return true
        }
        if (other is Package) {
            return this.trackingID == other.trackingID && this.destinationZip == other.destinationZip
        }
        return false
    }

}

fun main() {
    // This is how we know our current stuff works just fine
    val pkg1 = Package("ABC123", 10001, 40.7128, -74.0060, 5.0)
    println(pkg1)
    pkg1.updateLocation(40.730610, -73.935242, "Left the warehouse")
    println(pkg1)
    println("Package history:")
    for (entry in pkg1.history) {
        println(entry)
    }

    println("\nTesting equality:")
    val duplicatePkg = Package("ABC123", 10001, 0.0, 0.0, 1.0)
    println(duplicatePkg)
    println("pkg1 equals duplicatePkg: ${pkg1 == duplicatePkg}")

    val reusedID = Package("ABC123", 90210, 34.0736, -118.4004, 3.0)
    println("reusedID equals pkg1: ${reusedID == pkg1}") // Should be false since destinationZip is different, it's cheaper this way!

    pkg1.weight = 4.0 // Sometimes they shrink a bit along the way, but it's still the same package!
    println("pkg1 after weight update: $pkg1")
}