
/**
 * Abstract Class for a Plant.  Specifies the behaviors that all plants have.
 * 
 * Author: Anya Vostinar
 * Adapted from: Tanya Amert and Anna Rafferty
 */
abstract class Plant {
    abstract val species: String
    open var waterLevel: Int = 0
    open var age: Int = 0

    /**
     * Waters the plant with unitsWater water.
     */
    open fun waterPlant(unitsWater: Int) {
        this.waterLevel += unitsWater
    }

    /**
     * Ages the plant by a day.  This could change the
     * plant's water level or other characteristics.
     */
    open fun elapseDay() {
        age++
        waterLevel -= 1
    }

    /**
     * Returns a string describing the state of the plant.  E.g., might say
     * "overly dry" or "abundantly happy".  State of the plant may vary with
     * water level or other characteristics.
     */
    abstract fun getStatus(): String

    /**
    * Returns string to print the plant species and status.
    */
    override fun toString(): String {
        return "$species: ${getStatus()}"
    }

}