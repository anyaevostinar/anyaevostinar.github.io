import Heap

class MaxHeap<E: Comparable<E>>(): Heap<E>() {
    override fun shouldBeHigher(element1: E, element2: E): Boolean {
        return element1 > element2
    }

    /**Helper function to move max value to end of heap
     * Shrinks the heap but does not shrink the underlying array
    */
    fun moveMax() {
        //TODO
        
    }
}

/** Sorts given list using heapsort, list will be from least to greatest
 * List is sorted in place
     * param: MutableList<Int>, the list to be sorted
    */
fun heapsort(listToSort: MutableList<Int>) {
    //TODO

}

fun main() {

    var testList = mutableListOf(54, 26, 93, 17, 77, 31, 44, 55, 20)
    heapsort(testList)
    println(testList) //should print list sorted in increasing order
    testList = mutableListOf(2, 2, 1, 3, 2, 1)
    heapsort(testList)
    println(testList)
    testList = mutableListOf(-5, 2, -1, 0, -10)
    heapsort(testList)
    println(testList)

}