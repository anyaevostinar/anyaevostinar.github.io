import Sorter

class Shellsort : Sorter() {

    override fun <T: Comparable<T>> sort (list: MutableList<T>) {
        var sublistCount = list.count() / 2
        while (sublistCount > 0) {
            for (startPos in 0 ..< sublistCount) {
                gapInsertionSort(list, startPos, sublistCount)
            }
            sublistCount = sublistCount / 2
        }
    }

    fun <T: Comparable<T>> gapInsertionSort(list: MutableList<T>, start: Int, gap: Int) {
        for (i in start + gap ..< list.count() step gap) {
            val value = list[i]
            var position = i
            while (position >= gap && list[position - gap] > value) {
                list[position] = list[position - gap]
                position = position - gap
            }
            list[position] = value
        }
    }
}
