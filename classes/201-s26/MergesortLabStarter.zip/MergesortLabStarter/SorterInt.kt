abstract class Sorter {
    abstract fun <T: Comparable<T>> sort(list: MutableList<T>)
}