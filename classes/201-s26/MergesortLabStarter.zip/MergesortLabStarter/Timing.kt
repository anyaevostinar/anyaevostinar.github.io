// A class to time the execution of different sorting algorithms

import Mergesort
import InsertionSort
import Sorter
import Shellsort

fun timeFunction(sorter: Sorter, size: Int, reps: Int) {
    var totalTime = 0L
    for (i in 0..reps) {
        val array = IntArray(size) { (0..100000).random() }
        val startTime = System.nanoTime()
        sorter.sort(array.toMutableList())
        val endTime = System.nanoTime()
        if (i != 0) {
            // first time through oftern takes longer, so ignore it
            totalTime += (endTime - startTime)
        }
        
    }
    println("Average time for ${sorter::class.simpleName} with size $size over $reps reps: ${totalTime / reps / 1_000_000.0} ms")
}

fun timeBuiltIn(size: Int, reps: Int) {
    var totalTime = 0L
    for (i in 0..reps) {
        val array = IntArray(size) { (0..100000).random() }
        val startTime = System.nanoTime()
        array.sort()
        val endTime = System.nanoTime()
        if (i != 0) {
            // first time through oftern takes longer, so ignore it
            totalTime += (endTime - startTime)
        }
    }
    println("Average time for built-in sort with size $size over $reps reps: ${totalTime / reps / 1_000_000.0} ms")
}

fun main() {
    val reps = 1000
    val size = 10
    println("Timing sorting algorithms with size $size lists")
    timeFunction(Mergesort(), size, reps)
    timeFunction(InsertionSort(), size, reps)
    timeFunction(Shellsort(), size, reps)
    timeFunction(MergesortNewLists(), size, reps)
    timeBuiltIn(size, reps)
}