import Sorter

class InsertionSort : Sorter() {
    override fun <T: Comparable<T>> sort(list: MutableList<T>) {
        for (i in 1 ..< list.count()) {
            val value = list[i]
            var position = i

            while (position > 0 && list[position - 1] > value) {
                list[position] = list[position - 1]
                position = position - 1
            }
            list[position] = value
        }
    }
}