/*
 * Conditionals.kt
 * Anya Vostinar, 3/23/26
 * Based on Conditionals.kt by Tanya Amert
 * Based on Conditionals.java by Jeff Ondich, Anna Rafferty
 *
 * A tiny illustration of if-statements and console input.
 *
 * This is the Kotlin half of a pair of parallel examples in Python and Kotlin.
 * See conditionals.py.
 */

fun main() {

    // Get the number from the user
    print("Number, please: ")

    // Read in up until a newline
    val numberString: String = readln()   
    val number: Int = numberString.toInt() // convert to an Int

    // Print a message (or two) based on the number
    if (number == 16) {
        println("Sweet sixteen!")
    } else if (number == 17) {
        println("Yey, 17!")
    } else {
        println("Hm, it's not 16 or 17....")
    }

    // Kotlin has another way of doing conditionals:
    when {
        number > 100 -> println("Gosh, $number is a big number")
        number == 3 -> println("3 is my lucky number")
        number >= 0 -> println("$number is pretty little")
        else -> println("$number is negative")
    }
}