/*
 * Hello.kt
 * Anya Vostinar 3/23/26
 * Based on Hello.kt by Tanya Amert
 * Based on Hello.java by Jeff Ondich
 *
 * Hello world, Kotlin style.
 *
 * This is the Kotlin half of a pair of parallel examples in Python and Kotlin.
 * See hello.py.
 */

fun main() {
    println("Hello, world!")

    //Run this file with the following:
    //kotlinc Hello.kt
    //kotlin HelloKt
}