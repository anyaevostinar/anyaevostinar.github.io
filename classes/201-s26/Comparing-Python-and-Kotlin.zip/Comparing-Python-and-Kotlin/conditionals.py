"""
   conditionals.py
   Jeff Ondich, 2013-01-03
   Anna Rafferty

   Modified by Tanya Amert for Spring 2025

   A tiny illustration of if-statements and console input.

   Intended as the Python half of parallel examples in Python and
   Kotlin. See Conditionals.kt.
"""

# Get the number from the user
numberString = input("Number, please: ")
number = int(numberString)

# Print a message (or two) based on the number
if number == 16:
    print(f"Sweet sixteen!")
elif number == 17:
    print(f"Yey, 17!")
else:
    print("Hm, it's not 16 or 17....")

if number > 100:
    print(f"Gosh, {number} is a big number")
elif number == 3:
    print("3 is my lucky number")
elif number >= 0:
    print(f"{number} is pretty little")
else:
    print(f"{number} is negative")