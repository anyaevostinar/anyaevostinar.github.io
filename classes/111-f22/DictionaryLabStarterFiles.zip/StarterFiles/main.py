from ngrams import getOneGrams, getTwoGrams, printTopN

def main():
    filename = "corpora/Shakespeare/Hamlet.txt"
    oneGramDict = getOneGrams(filename)
    printTopN(oneGramDict, 10)

if __name__ == '__main__':
    main()
