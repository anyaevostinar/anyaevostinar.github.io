/*
 * Author: TODO
 *
 * Collaboration: TODO
 */

#include "ds.h"

///////////////////////////////////////////////////////////////////////////
// Function to define: Core                                              //
///////////////////////////////////////////////////////////////////////////

void split_label(int label, int *id_addr, int *entry_num_addr, int *data_pos_addr)
{
    return;
}

///////////////////////////////////////////////////////////////////////////
// Functions to define: Advanced                                         //
///////////////////////////////////////////////////////////////////////////

void store_string(data_store_t *data_store, int label, char *s)
{
    return;
}

int lookup_string(data_store_t *data_store, int label, char *dest)
{
    return DS_LOOKUP_FAILURE;
}

///////////////////////////////////////////////////////////////////////////
// Functions you've been given                                           //
///////////////////////////////////////////////////////////////////////////

void initialize_data_store(data_store_t *data_store)
{
    for (int i = 0; i < DS_NUM_ENTRIES; i++)
    {
        data_store->entries[i].id = 0;
        memset(data_store->entries[i].data, DS_DEFAULT_BYTE, DS_NUM_BYTES_PER_ENTRY);
    }
}

void print_data_store(data_store_t *data_store, int print_type)
{
    printf("\n");

    for (int i = 0; i < DS_NUM_ENTRIES; i++)
    {
        printf("[entry ID: 0x%x, id: 0x%08x] ", i, data_store->entries[i].id);

        for (int j = 0; j < DS_NUM_BYTES_PER_ENTRY; j++)
        {
            if (print_type == DS_PRINT_HEX)
            {
                // Print it out in hex
                printf("0x%02x ", data_store->entries[i].data[j]);
            }
            else
            {
                // Check for whether it's a blank character (NULL terminator)
                if (data_store->entries[i].data[j] == '\0')
                {
                    // Print out the blank character
                    printf(" \\0");
                }
                else
                {
                    // Print the character
                    printf("  %c", data_store->entries[i].data[j]);
                }
            }
        }

        printf("\n");
    }
}