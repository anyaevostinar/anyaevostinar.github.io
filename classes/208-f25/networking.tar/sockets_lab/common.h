#ifndef __COMMON_H__
#define __COMMON_H__

/*
    common.h

    Bridger Herman for CS208 W25
    with modifications by Tanya Amert for CS208 S25

    Common constants for UDP server/client
*/

#define BUFFER_SIZE 256
#define PORT 10000

#endif // __COMMON_H__