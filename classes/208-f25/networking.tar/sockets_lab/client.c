/*
    client.c

    Arpaci-Dusseau, OSTEP v1.10, Chapter 48
    With modifications by Bridger Herman for CS208 W25
    and Tanya Amert for CS208 S25

    Example UDP Code (client.c, server.c)

    Compile with:

        gcc -Wall -Werror -o client client.c
*/

#include <netdb.h>
#include <unistd.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <string.h>

#include "common.h"

// Client: Sets up a socket to connect to the server, and sends
// a single message.
int main(int argc, char *argv[])
{
    // Set up message buffer and socket vars
    // 5) TODO (last, if you have time): prompt the user for message, either
    // with command line args or scanf() or fgets()
    char message[BUFFER_SIZE] = "Hello world!";

    // Clear server address and initialize to localhost information
    struct sockaddr_in servaddr; 
    bzero(&servaddr, sizeof(servaddr)); 
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1"); 
    servaddr.sin_port = htons(PORT); 
    servaddr.sin_family = AF_INET; 

    // 1) TODO: use socket() to create a UDP (SOCK_DGRAM) socket, and error
    // check.
    int sockfd;


    // 2) TODO: use connect() to connect to the server with the above `servaddr`
    // information, and error check.


    // Send the message packets over UDP
    // We already specified the connection address with connect() so we don't
    // have to re-specify here.

    // 3) TODO: use send() to send packets to the server
    

    // 4) TODO: uncomment
    // printf("Sent bytes: %d\n", sent_bytes);

    // Remember to close the file!
    close(sockfd); 
}