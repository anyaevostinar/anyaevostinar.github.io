Bits and character encodings
CS208 Intro to Computer Systems
20 January 2022
Updated Fall 2024

For this assignment, we have included:

  bits.h - function prototypes and documentation; this is
      where you'll learn what you need to do.
      DO NOT CHANGE THIS FILE

  bits.c - stubs of the functions you will be implementing

  main.c - a quick sample main() for testing to_lower and to_upper.
      edit this one as you see fit--we'll ignore it
      when grading

  Makefile - a convenience for building and testing--edit
      however you wish--again, we'll ignore it

  a couple .txt files for testing

To use the existing Makefile

    make
        to build "bits"

    make test
        to run a couple tiny tests (entirely insufficient
        as they stand for testing boundary cases)
