# Puzzle 7
#
# Structures used: TODO
#
# Possible order of labels (#1): TODO
# Possible order of labels (#2): TODO
# Possible order of labels (#3): TODO
#
# Registers and sizes for inputs: TODO

function1:
    cmpw    $9, %di
    ja      .L9             # Next: TODO
CA:
    movzwl  %di, %eax
    jmp     *.L11(,%rax,8)  # Next: TODO
.L14:
    movl    $3, %eax
    ret
.L15:
    movswl  %si, %esi
    leal    10(%rsi), %eax
    ret
.L13:
    movswl  %si, %esi
    leal    (%rsi,%rsi,4), %eax
    addl    %eax, %eax
    ret
.L10:
    movl    $10, %eax
    movl    %esi, %ecx
    sarl    %cl, %eax
    ret
.L9:
    xorl    %edi, %esi
    movswl  %si, %eax
    ret
.L16:
    movl    $14, %eax
    ret 
.L11:
    .quad   .L9
    .quad   .L15
    .quad   .L14
    .quad   .L14
    .quad   .L9
    .quad   .L9
    .quad   .L13
    .quad   .L16
    .quad   .L9
    .quad   .L10