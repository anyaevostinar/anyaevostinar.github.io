# Puzzle 1
#
# Structures used: TODO
#
# Possible order of labels (#1): TODO
# Possible order of labels (#2): TODO
# Possible order of labels (#3): TODO
#
# Registers and sizes for inputs: TODO

function1:
    movl %esi, %eax
    cmpl %esi, %edi
    jge .L2             # Next: TODO
CA:
    movl %edi, %eax
.L2:
    ret