# Puzzle 6
#
# Structures used: TODO
#
# Possible order of labels (#1): TODO
# Possible order of labels (#2): TODO
# Possible order of labels (#3): TODO
#
# Registers and sizes for inputs: TODO

function1:
    movl $1, %r9d
    jmp .L2                       # Next: TODO
.L5:
    movl %ecx, (%rdi,%rax)
    subl $1, %edx
.L3:
    testl %edx, %edx
    jle .L4                       # Next: TODO
CA:
    movslq %edx, %rax
    salq $2, %rax
    movl -4(%rdi,%rax), %ecx
    cmpl %r8d, %ecx
    jg .L5                        # Next: TODO
.L4:
    movslq %edx, %rdx
    movl %r8d, (%rdi,%rdx,4)
    addl $1, %r9d
.L2:
    cmpl %esi, %r9d
    jge .L7                       # Next: TODO
CB:
    movslq %r9d, %rax
    movl (%rdi,%rax,4), %r8d
    movl %r9d, %edx
    jmp .L3                       # Next: TODO
.L7:
    ret