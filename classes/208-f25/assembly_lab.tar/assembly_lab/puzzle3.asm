# Puzzle 3
#
# Structures used: TODO
#
# Possible order of labels (#1): TODO
# Possible order of labels (#2): TODO
# Possible order of labels (#3): TODO
#
# Registers and sizes for inputs: TODO

function1:
    testq %rdi, %rdi
    sete %al
    testq %rsi, %rsi
    sete %dl
    orb %dl, %al
    je .L3              # Next: TODO
CA:
    ret
.L4:
    movb %al, (%rdi)
    addq $1, %rdi
    addq $1, %rsi
.L3:
    movzbl (%rsi), %eax
    testb %al, %al
    jne .L4             # Next: TODO
CB:
    movb $0, (%rdi)
    ret