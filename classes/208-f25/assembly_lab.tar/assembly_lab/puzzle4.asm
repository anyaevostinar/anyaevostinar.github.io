# Puzzle 4
#
# Structures used: TODO
#
# Possible order of labels (#1): TODO
# Possible order of labels (#2): TODO
# Possible order of labels (#3): TODO
#
# Registers and sizes for inputs: TODO

function1:
    testl %edi, %edi
    jle .L3                   # Next: TODO
CA:
    pushq %rbp
    pushq %rbx
    subq $8, %rsp
    movl %edi, %ebx
    cmpl $1, %edi
    je .L4                    # Next: TODO
CB:
    leal -1(%rdi), %edi
    call function1            # Next: TODO
CC:
    movl %eax, %ebp
    leal -2(%rbx), %edi
    call function1            # Next: TODO
CD:
    addl %ebp, %eax
.L1:
    addq $8, %rsp
    popq %rbx
    popq %rbp
    ret
.L3:
    movl $0, %eax
    ret
.L4:
    movl %edi, %eax
    jmp .L1                   # Next: TODO