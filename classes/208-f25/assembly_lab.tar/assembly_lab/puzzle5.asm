# Puzzle 5
#
# Structures used: TODO
#
# Possible order of labels (#1): TODO
# Possible order of labels (#2): TODO
# Possible order of labels (#3): TODO
#
# Registers and sizes for inputs: TODO

function1:
    testl %edi, %edi
    jle .L5                     # Next: TODO
CA:
    movl $1, %edx
    movl $1, %eax
    movl $0, %ecx
    jmp .L3                     # Next: TODO
.L4:
    leal (%rcx,%rax), %esi
    addl $1, %edx
    movl %eax, %ecx
    movl %esi, %eax
.L3:
    cmpl %edi, %edx
    jl .L4                      # Next: TODO
CB:
    ret
.L5:
    movl $0, %eax
    ret