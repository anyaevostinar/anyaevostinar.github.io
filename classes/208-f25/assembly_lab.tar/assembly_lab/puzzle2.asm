# Puzzle 2
#
# Structures used: TODO
#
# Possible order of labels (#1): TODO
# Possible order of labels (#2): TODO
# Possible order of labels (#3): TODO
#
# Registers and sizes for inputs: TODO

function2:
    movl %esi, %eax
    cmpl %esi, %edi
    jge .L2             # Next: TODO
CA:
    movl %edi, %eax
.L2:
    ret
function1:
    pushq %rbx
    movl %edx, %ebx
    call function2      # Next: TODO
CB:
    movl %eax, %edi
    movl %ebx, %esi
    call function2      # Next: TODO
CC:
    popq %rbx
    ret