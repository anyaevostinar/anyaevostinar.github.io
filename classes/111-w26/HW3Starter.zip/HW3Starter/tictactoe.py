# File: tictactoe.py
# Purpose: A game of tic-tac-toe to be played between two players.
# Author: TODO
#
# Collaboration statement: TODO
#
# Inputs: mouse clicks!

from graphics import *

##############################################################
## Helper functions for Tic-Tac-Toe                         ##
##############################################################

def create_and_draw_board():
    """
    Creates a window and draws the board in it.

    returns: a GraphWin object
    """
    # Create the window
    win = GraphWin("Tic Tac Toe", 600, 600)
    win.setCoords(-0.25, 3.75, 3.25, -0.25) # give a little buffer
    win.setBackground("white")

    # Draw the lines
    for i in range(1, 3):
        horizontal_line = Line(Point(0, i), Point(3, i))
        horizontal_line.draw(win)
        
        vertical_line = Line(Point(i, 0), Point(i, 3))
        vertical_line.draw(win)

    # Return the window
    return win

def set_player_text(label, player):
    """
    Updates the player text label to indicate whose turn it is.

    label: a Text object
    player: 1 or 2
    """
    if player == 1:
        label.setText("Player 1, please place an X.")
    else:
        label.setText("Player 2, please place an O.")

def get_grid_location(point):
    """
    Returns the x,y grid coordinates of a point.

    point: a Point object
    returns: a pair of grid positions: x,y
    """
    grid_x = int(point.getX())
    grid_y = int(point.getY())
    return grid_x, grid_y

##############################################################
## Part 1: Keeping track of game state                      ##
##############################################################

def get_cell_string(grid_value):
    """
    Returns a string corresponding to the provided value from the board state.

    grid_value: 0 (none) or 1 (player 1) or 2 (player 2)
    returns: " " (0) or "x" (player 1) or "o" (player 2)
    """
    # TODO: Part 1
    return "" # replace with your code

def print_row(board_state, row):
    """
    Prints out the current board state of the given row.

    board_state: a nested list containing the board state
    row: the row for which to print the board state
    """
    # TODO: Part 1
    pass # replace with your code

def print_board_state(board_state):
    """
    Prints out the current board state for debugging.

    board_state: a nested list containing the board state
    """
    print()
    
    # Print top row
    print_row(board_state, 0)
    
    # Divider line
    print("-----")

    # Print middle row
    print_row(board_state, 1)
    
    # Divider line
    print("-----")

    # Print bottom row
    print_row(board_state, 2)

##############################################################
## Part 2: Placing pieces                                   ##
##############################################################

def draw_x(win, grid_x, grid_y):
    """
    Draws an X at the specified grid position.

    win: the GraphWin for the board
    grid_x: x-coordinate of grid cell (column)
    grid_y: y-coordinate of grid cell (row)
    """
    # TODO: Part 2
    pass # replace with your code

def draw_o(win, grid_x, grid_y):
    """
    Draws an O at the specified grid position.

    win: the GraphWin for the board
    grid_x: x-coordinate of grid cell (column)
    grid_y: y-coordinate of grid cell (row)
    """
    # TODO: Part 2
    pass # replace with your code

def draw_player_marker(win, grid_x, grid_y, player):
    """
    Draws a player marker (X for player 1, O for player 2)
    at the specified grid position.

    win: the GraphWin for the board
    grid_x: x-coordinate of grid cell (column)
    grid_y: y-coordinate of grid cell (row)
    player: 1 or 2
    """
    if player == 1:
        draw_x(win, grid_x, grid_y)
    else: # must be 2
        draw_o(win, grid_x, grid_y)

##############################################################
## Part 3: Checking for valid positions                     ##
##############################################################

def is_valid_grid_cell(board_state, grid_x, grid_y):
    """
    Returns a Boolean indicating whether the given grid position
    is a valid selection given the current board state.
    Also checks if the grid position is within the bounds of the board.

    board_state: a nested list containing the board state
    grid_x: x-coordinate of grid cell (column)
    grid_y: y-coordinate of grid cell (row)
    returns: True if a piece can be placed at (grid_x, grid_y),
             False otherwise
    """
    # TODO: Part 3
    return True # replace with your code

def update_board_state(board_state, grid_x, grid_y, player):
    """
    Updates the board state to indicate a player placed
    a marker at the specified grid position on the board.

    board_state: a nested list containing the board state
    grid_x: x-coordinate of grid cell (column)
    grid_y: y-coordinate of grid cell (row)
    player: 1 or 2
    """
    # TODO: Part 3
    return True # replace with your code

##############################################################
## Part 4: Ending the game                                  ##
##############################################################

def is_draw(board_state):
    """
    Returns a Boolean indicating whether the game has ended in a draw.
    Assumes neither player has won.
    
    board_state: a nested list containing the board state
    returns: a Boolean (True if the game is a draw, False otherwise)
    """
    # TODO: Part 4a
    return False # replace with your code

def did_player_win_with_row(board_state, player, row):
    """
    Returns a Boolean indicating whether the player
    won the game due to the given row.

    board_state: a nested list containing the board state
    player: 1 or 2
    row: 0, 1, or 2
    returns: a Boolean (True if the player has an entire row,
             False otherwise)
    """
    # TODO: Part 4b
    return False # replace with your code

def did_player_win_with_column(board_state, player, col):
    """
    Returns a Boolean indicating whether the player
    won the game due to the given column.

    board_state: a nested list containing the board state
    player: 1 or 2
    col: 0, 1, or 2
    returns: a Boolean (True if the player has an entire column,
             False otherwise)
    """
    # TODO: Part 4b
    return False # replace with your code

def did_player_win_with_diagonal(board_state, player):
    """
    Returns a Boolean indicating whether the player
    won the game due to either diagonal.

    board_state: a nested list containing the board state
    player: 1 or 2
    returns: a Boolean (True if the player has an entire diagonal,
             False otherwise)
    """
    # TODO: Part 4b
    return False # replace with your code

def did_player_win(board_state, player):
    """
    Returns a Boolean indicating whether the player has
    won the game.
    
    board_state: a nested list containing the board state
    player: 1 or 2
    returns: a Boolean (True if the player won, False otherwise)
    """
    # First, check the rows
    for row in range(3):
        if did_player_win_with_row(board_state, player, row):
            return True

    # Second, check the columns
    for col in range(3):
        if did_player_win_with_column(board_state, player, col):
            return True

    # Finally, check the diagonals
    if did_player_win_with_diagonal(board_state, player):
        return True

    # No win condition was met
    return False

##############################################################
## Testing code                                             ##
##############################################################

def test_get_cell_string():
    """
    Tests get_cell_string by checking that the correct value is returned.
    """
    res1 = get_cell_string(0) == " "
    res2 = get_cell_string(1) == "x"
    res3 = get_cell_string(2) == "o"
    print("Testing get_cell_string():",
          "passed\n" if res1 and res2 and res3 else "failed\n")

def test_print_board_state():
    """
    Tests draw_player_marker by drawing five pieces based on where
    the user clicks.  Does not check for the location being valid,
    just tests the drawing code.
    """
    # Test getCellString() first
    test_get_cell_string()

    # Set up the board state
    board_state = [[2,0,0], # top row
                  [1,2,0], # middle row
                  [0,1,0]] # bottom row

    # Print out the actual list
    print("Testing print_board_state() now.")
    print("The board_state list is:", board_state)

    # Print out the board state (useful for debugging)
    print_board_state(board_state)

    # Print the expected result
    print("\nThe expected board state is:\n")
    print("o| | ")
    print("-----")
    print("x|o| ")
    print("-----")
    print(" |x| ")
    print()

def test_draw_player_marker():
    """
    Tests draw_player_marker by drawing five pieces based on where
    the user clicks.  *Does not* check for the location being valid,
    just tests the drawing code.
    """
    # Create and set up the board
    win = create_and_draw_board()

    # Add a label to indicate to the players whose turn it is
    text_label = Text(Point(1.5, 3.5),
                     "Place five markers.  Click anywhere to start.")
    text_label.draw(win)
    win.getMouse() # wait until they click to start it all

    # Start with player 1
    player = 1

    # Draw five pieces
    for i in range(5):
        # Update the player text
        set_player_text(text_label, player)

        # Wait for the player to click a valid grid cell
        grid_x, grid_y = get_grid_location(win.getMouse())

        # Draw a marker for the current player
        draw_player_marker(win, grid_x, grid_y, player)

        # Switch players
        player = 3 - player # switches between 1 and 2

    # Update the text label -- we're done
    text_label.setText("All done -- click again to quit.")
    win.getMouse()
    win.close()

def test_placing_valid_markers():
    """
    Tests draw_player_marker by drawing five pieces based on where
    the user clicks.  *Does* check for the location being valid, and
    updates the board state as it goes.
    """
    # Create and set up the board
    win = create_and_draw_board()

    # Add a label to indicate to the players whose turn it is
    text_label = Text(Point(1.5, 3.5),
                     "Place five markers.  Click anywhere to start.")
    text_label.draw(win)
    win.getMouse() # wait until they click to start it all

    # Start with player 1
    player = 1

    # Maintain the board state as a list of lists; each list
    # corresponds to a row on the game board
    board_state = [[0, 0, 0], # top row
                  [0, 0, 0], # middle row
                  [0, 0, 0]] # bottom row

    # Draw five pieces
    for i in range(5):
        # Update the player text
        set_player_text(text_label, player)

        # Wait for the player to click a valid grid cell
        is_valid_cell = False
        while not is_valid_cell:
            grid_x, grid_y = get_grid_location(win.getMouse())
            is_valid_cell = is_valid_grid_cell(board_state, grid_x, grid_y)

        # Update the board state
        update_board_state(board_state, grid_x, grid_y, player)

        # For debugging: print the board state
        print_board_state(board_state)

        # Draw a marker for the current player
        draw_player_marker(win, grid_x, grid_y, player)

        # Switch players
        player = 3 - player # switches between 1 and 2

    # Update the text label -- we're done
    text_label.setText("All done -- click again to quit.")
    win.getMouse()
    win.close()

##############################################################
## The actual game                                          ##
##############################################################

def play_game():
    """
    Play a game of Tic Tac Toe.
    """
    # Create and set up the board
    win = create_and_draw_board()

    # Add a label to indicate to the players whose turn it is
    text_label = Text(Point(1.5, 3.5), "")
    text_label.draw(win)

    # Start with player 1
    player = 1

    # Maintain the board state as a list of lists; each list
    # corresponds to a row on the game board
    board_state = [[0, 0, 0], # top row
                  [0, 0, 0], # middle row
                  [0, 0, 0]] # bottom row

    # Loop until the game is over
    is_game_over = False
    while not is_game_over:
        # Update the player text
        set_player_text(text_label, player)

        # Wait for the player to click a valid grid cell
        is_valid_cell = False
        while not is_valid_cell:
            grid_x, grid_y = get_grid_location(win.getMouse())
            is_valid_cell = is_valid_grid_cell(board_state, grid_x, grid_y)

        # Update the board state
        update_board_state(board_state, grid_x, grid_y, player)

        # For debugging: print the board state
        print_board_state(board_state)

        # Draw a marker for the current player
        draw_player_marker(win, grid_x, grid_y, player)

        # Check if the game is over; if not, switch players
        if did_player_win(board_state, player):
            text_label.setText(f"Player {player} wins!")
            is_game_over = True
        elif is_draw(board_state):
            text_label.setText("The game is a draw.")
            is_game_over = True
        else:
            player = 3 - player # switches between 1 and 2

    # We're done -- wait for the user to click
    win.getMouse()
    win.close()

if __name__ == "__main__":
    # Part 1
    test_print_board_state()

    # Part 2
    # test_draw_player_marker()

    # Part 3
    # test_placing_valid_markers()

    # Part 4
    # play_game()