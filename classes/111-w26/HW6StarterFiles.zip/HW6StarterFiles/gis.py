# gis.py
# Starter code by David Liben-Nowell and Anya Vostinar
#  for CS 111, Carleton College
# Authors: 

from graphics import *
import canvasvg

max_lat = 49.3828    + .1 # MN northernmost point, near Angle Inlet, MN + buffer
min_lat = 43.30      - .1 # MN southernmost point, the entire IA border + buffer
max_lon = -89.483317 + .5 # MN easternmost point, near Pigeon Point, MN + buffer
min_lon = -97.226111 - .5 # MN westernmost point, <=3 miles from Canada + buffer

class ZipCode:
    def __init__(self, zipcode, lat, lon, population):
        '''Construct a new ZipCode object. The constructor takes as input the
           zipcode itself (an integer), and the latitude/longitude of
           the geographic center of the zipcode region.  For the
           moment, the constructor merely constructs a new ZipCode
           object, which stores all of the above information.'''
        pass #FIX ME

    def get_zip(self):
        '''Returns this ZipCode's 5-digit name.'''
        return 0 # fix me!

    def get_population(self):
        '''Returns this ZipCode's population.'''
        return 0  # fix me!
    
    def get_latitutde(self):
        '''Returns this ZipCode's latitude.'''
        return 0 # fix me
    
    def get_longitude(self):
        '''Returns this ZipCode's longitude.'''
        return 0 # fix me

    def get_x(self, window):
        '''Returns the x-coordinate of this ZipCode in the given window (after
           longitudes are scaled so min_lon/max_lon are left/right edges).'''
        total_diff_lon = max_lon - min_lon
        scaled_lon = self.get_longitude() - min_lon
        return window.getWidth() * scaled_lon / total_diff_lon

    def get_y(self, window):
        '''Returns the y-coordinate of this ZipCode in the given window (after
           latitudes are scaled so min_lat/max_lat are bottom/top edges).'''
        total_diff_lat = max_lat - min_lat
        scaled_lat = self.get_latitutde() - min_lat
        return window.getHeight() * (1 - scaled_lat / total_diff_lat)
  
    def draw_circle(self, window):
        '''TODO'''
        #pass just keeps the starter code from crashing, remove when you add code
        pass

def load_data(filename):
    '''Builds a list of ZipCode objects, loading the relevant data from the given file.
    Input: filename, a string, the name of the file that contains zip code data.
    Output: a list of ZipCode objects.'''
    f = open(filename)
    field_names = f.readline().strip().split(",")

    for line in f:
        fields = line.strip().split(",")
        zipcode = int(fields[field_names.index("ZCTA5CE10")])
        latitude = float(fields[field_names.index("INTPTLAT10")])
        longitude = float(fields[field_names.index("INTPTLON10")])
        land_area = float(fields[field_names.index("ALAND10")])   # in square meters
        water_area = float(fields[field_names.index("AWATER10")]) # in square meters
        population = int(fields[field_names.index("Population_Per_MN_Demographics")])
        #TODO: should probably do something with all that data huh?
    f.close()
    return [] # fix me!

def main():
    zips = load_data("zip_code_tabulation_areas.csv")
    width, height = 600, 600
    window = GraphWin('Minnesota', width, height)

    #These two lines just keep the starter code from crashing
    #Delete them once you're drawing circles in the right places
    example = Text(Point(100, 100), "TODO")
    example.draw(window)

    for zipcode in zips:
        zipcode.draw_circle(window)



    #This line saves the window as an SVG file, don't change it!
    canvasvg.saveall("Minnesota.svg", window)

if __name__ == "__main__":
    main()
