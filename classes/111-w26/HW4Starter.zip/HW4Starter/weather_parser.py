# File: weather_parser.py
#
# Parses weather data.
# Assumes CSV input has the following columns:
# - NAME (e.g., "MINNEAPOLIS ST. PAUL INTERNATIONAL AIRPORT")
# - DATE (e.g., "1/19/2023")
# - PRCP (e.g., "0.16) <- string representing a float
# - SNOW (e.g., "3.5") <- string representing a float
# - TMAX (e.g., "32") <- string representing an int
# - TMIN (e.g., "27") <- string representing an int
#
# Author: TODO
#
# Collaboration statement: TODO
#
# Inputs: CSV file

def parse_data(filename):
    """
    Opens the CSV file with name filename for reading, and reads in the data.

    filename: string
    returns: five lists:
      - one of dates (strings)
      - one of precipitation (floats)
      - one of snow (floats)
      - one of minimum temps (ints)
      - one of maximum temps (ints)
    """
    dates = []
    precip = []
    snow = []
    min_temps = []
    max_temps = []

    # TODO: Part 2a
    # your code here

    return dates, precip, snow, min_temps, max_temps

def get_lowest_temp(dates, temps):
    """
    Finds the date and temperature corresponding to the lowest
    temperature across a date range.

    dates: list of strings
    temps: list of ints

    Returns: lowest temperature (int) and its corresponding date (string)
    """
    lowest_temp = 0  # replace with your code
    lowest_date = "" # replace with your code

    # TODO: Part 2b
    return lowest_date, lowest_temp

def get_highest_temp(dates, temps):
    """
    Finds the date and temperature corresponding to the highest
    temperature across a date range.

    dates: list of strings
    temps: list of ints

    Returns: highest temperature (int) and its corresponding date (string)
    """
    highest_temp = 0  # replace with your code
    highest_date = "" # replace with your code

    # TODO: Part 2b
    return highest_date, highest_temp

def output_results(dates, min_temps, max_temps):
    """
    Uses the command line arguments to report out a specific temperature
    and metric to the user. First argument should be min or max.
    Second argument should be highs or lows.

    dates: a list of strings
    min_temps: list of ints
    max_temps: list of ints

    Returns: None
    """
    # TODO: Part 2c
    pass # replace with your code

def main():
    # Parse the data from the CSV file
    filename = "weatherData.csv"
    dates, precip, snow, mins, maxes = parse_data(filename)

    # Output the results to the user in a loop, until
    # they say they're done
    output_results(dates, mins, maxes)

# A new structure we're seeing to only call main() if you run
# this file, rather than importing it
if __name__ == "__main__":
    main()