# File: shape_parser.py
# Purpose: Parses a CSV file of shapes and draws them to the window.
# Author: TODO
#
# Collaboration statement: TODO
#
# Inputs: CSV file

from graphics import *
import canvasvg

def parse_circle(vals):
    """
    Creates a Circle object based on the values given in vals.

    Assumes vals is either a list [x,y,r,color] of strings,
    or [x,y,r].

    x: x-coordinate of center point (expect an int in the str)
    y: y-coordinate of center point (expect an int in the str)
    r: radius (expect a float in the str)
    color: optional color (str)

    Returns: the Circle object
    """
    # TODO: Part 1a
    return Circle(Point(0,0),0) # replace with your code

def parse_square(vals):
    """
    Creates a Rectangle object representing a square based
    on the values given in vals.

    Assumes vals is either a list [x,y,s,color] of strings,
    or [x,y,s].

    x: x-coordinate of center point (expect an int in the str)
    y: y-coordinate of center point (expect an int in the str)
    s: side length (expect an int in the str)
    color: optional color (str)

    Returns: the Rectangle object representing the square
    """
    # TODO: Part 1a
    return Rectangle(Point(0,0), Point(0,0)) # replace with your code

def parse_rectangle(vals):
    """
    Creates a Rectangle object based on the values given in vals.

    Assumes vals is either a list [x1,y1,x2,y2,color] of strings,
    or [x1,y1,x2,y2].

    x1: x-coordinate of first point (expect an int in the str)
    y1: y-coordinate of first point (expect an int in the str)
    x2: x-coordinate of second point (expect an int in the str)
    y2: y-coordinate of second point (expect an int in the str)
    color: optional color (str)

    Returns: the Rectangle object
    """
    # TODO: Part 1a
    return Rectangle(Point(0,0), Point(0,0)) # replace with your code

def parse_triangle(vals):
    """
    Creates a Triangle object based on the values given in vals.

    Assumes vals is either a list [x1,y1,x2,y2,x3,y3,color] of
    strings, or [x1,y1,x2,y2,x3,y3].

    x1: x-coordinate of first point (expect an int in the str)
    y1: y-coordinate of first point (expect an int in the str)
    x2: x-coordinate of second point (expect an int in the str)
    y2: y-coordinate of second point (expect an int in the str)
    x3: x-coordinate of third point (expect an int in the str)
    y3: y-coordinate of third point (expect an int in the str)
    color: optional color (str)

    Returns: the Polygon object representing the Triangle
    """
    # TODO: Part 1a
    return Polygon([Point(0,0), Point(0,0), Point(0,0)]) # replace with your code

def parse_shapes_from_file(filename):
    """
    Opens the file specified by filename for reading, and parses
    the window dimensions and the shapes.

    Returns: the Window object and a list of shapes
    """
    # Specify variables for the window and the shape list
    # Open the file for reading
        # Go through each line in the file
            # Skip over any empty lines
            # Split the line into strings on the commas
            # Use the first string in the line to determine which object to create
    # Return the window and shapes list
    
    # TODO: Part 1b
    pass # replace with your code

def main():
    # Read in the provided file and parse it into a window and shapes
    filename = "shapes.csv"
    win, shapes = parse_shapes_from_file(filename)

    # Draw each shape (in order) in the window
    # Part 1c
    pass # TODO: replace with your code

    # Save the picture based on the input file
    file_prefix = filename.split(".")[0]
    canvasvg.saveall(file_prefix+".svg", win)

# A new structure we're seeing to only call main() if you run
# this file, rather than importing it
if __name__ == "__main__":
    main()