import java.util.*;

class Main {

  public static Map<Integer, Integer> BFS(UnweightedGraph input, Integer start) {
    throw new UnsupportedOperationException();
  }

  public static void main(String[] args) {
    //Your code here!
  ;

  }
}