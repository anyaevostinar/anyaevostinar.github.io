import java.util.*;

class Main {

  public static void fillAndShuffle(Integer[] a) {
      // Fill the array with the integers including duplicates.
      for (int k = 0; k < a.length; k++) {
          a[k] = (int)Math.floor(k/2);
      }

      // Shuffle.
      for (int k = a.length - 1; k > 0; k--) {
          int swapIndex = (int)Math.floor(Math.random() * (k + 1));
          int temp = a[k];
          a[k] = a[swapIndex];
          a[swapIndex] = temp;
      }
  }

  static void swap(Integer[] A, int i, int j) {
    Integer temp = A[i];
    A[i] = A[j];
    A[j] = temp;
  }

  static int partition(Integer[] A, int left, int right, Integer pivot) {
    // Move bounds inward until they meet
    while (left < right) { 
      while (A[left].compareTo(pivot) < 0) left++;
      while ((right > left) && (A[right].compareTo(pivot) > 0)) right--;
      if (right > left) swap(A, left, right); // Swap out-of-place values
    }
    return left;            // Return first position in right partition
  }

  static int findpivot(Integer[] A, int i, int j)
    { return (i+j)/2; }

  static void quicksort(Integer[] A, int i, int j) {
    int pivotindex = findpivot(A, i, j);  // Pick a pivot
    // k will be the first position in the right subarray
    int k = partition(A, i, j-1, A[j]);
    if ((k-i) > 1) quicksort(A, i, k-1);  // Sort left partition
    if ((j-k) > 1) quicksort(A, k+1, j);  // Sort right partition
  }

  static void printArray(Integer[] input) {
    System.out.println("-----------------");
    for(int i=0; i<input.length; i++) {
      System.out.print(input[i] + " ");
    }
    System.out.println();
  }

  public static void main(String[] args) {
    Integer[] example = new Integer[100];
    fillAndShuffle(example);
    System.out.println("Unsorted: ");
    printArray(example);
    quicksort(example, 0, example.length-1);
    System.out.println("Sorted: ");
    printArray(example);
  }
}