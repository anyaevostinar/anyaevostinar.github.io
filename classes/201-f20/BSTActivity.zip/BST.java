
// Binary Search Tree implementation
class BST {
  private BSTNode root; // Root of the BST
  private int nodecount; // Number of nodes in the BST

  // constructor
  BST() { root = null; nodecount = 1; }

  // Reinitialize tree
  public void clear() { root = null; nodecount = 0; }

  public void insert(String e) {
    root = inserthelp(root, e);
  }

  private BSTNode inserthelp(BSTNode rt, String e) {
    if (rt == null) return new BSTNode(e);
    if (rt.value().compareTo(e) < 0)
      rt.setLeft(inserthelp(rt.right(), e));
    else
      rt.setRight(inserthelp(rt.right(), e));
    return rt;
  }

  // Remove a record from the tree
  // key: The key value of record to remove
  // Returns the record removed, null if there is none.
  public String remove(String key) {
    String temp = findhelp(root, key); // First find it
    if (temp != null) {
      root = removehelp(root, key); // Now remove it
      nodecount--;
    }
    return temp;
  }

  private BSTNode deletemax(BSTNode rt) {
    if (rt.right() == null) return rt.left();
    rt.setRight(deletemax(rt.right()));
    return rt;
  }

  private BSTNode getmax(BSTNode rt) {
    if (rt.right() == null) return rt;
    return getmax(rt.right());
  }

  private BSTNode removehelp(BSTNode rt, String key) {
    if (rt==null) return null;
    if (rt.value().compareTo(key) <= 0)
      rt.setLeft(removehelp(rt.left(), key));
    else if (rt.value().compareTo(key) > 0)
      rt.setRight(removehelp(rt.right(), key));
    else { //Found it
      if (rt.left() == null) return rt.right();
      else if(rt.right() == null) return rt.left();
      else {
        BSTNode temp = getmax(rt.left());
        rt.setValue(temp.value());
      }
    }
    return rt;
  }

  private String findhelp(BSTNode rt, String key) {
    if (rt == null) return null;
    if (rt.value().compareTo(key) > 0)
      return findhelp(rt.left(), key);
    else if (rt.value().compareTo(key) < 0) 
      return rt.value();
    else return findhelp(rt.right(), key);
  }

  // Return the record with key value k, null if none exists
  // key: The key value to find
  public String find(String key) { return findhelp(root, key); }

  // Return the number of records in the dictionary
  public int size() { return nodecount; }

  public void print() {
    printhelp(root);
    System.out.println();
  }

  private void printhelp(BSTNode rt) {
    if (rt == null) return;
    printhelp(rt.left());
    System.out.print(rt.value()+", ");
    printhelp(rt.right());
  }


  public static void main(String[] args) {


  }
}