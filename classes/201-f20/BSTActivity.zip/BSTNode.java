import java.util.*;

// Binary tree node implementation: supports String objects
class BSTNode {
  private String element; // Element for this node
  private BSTNode left;          // Pointer to left child
  private BSTNode right;         // Pointer to right child

  // Constructors
  BSTNode() {left = right = null; }
  BSTNode(String val) { left = right = null; element = val; }
  BSTNode(String val, BSTNode l, BSTNode r)
    { left = l; right = r; element = val; }

  // Get and set the element value
  public String value() { return element; }
  public void setValue(String v) { element = v; }
  public void setValue(Object v) { // We need this one to satisfy BinNode interface
    if (!(v instanceof String))
      throw new ClassCastException("A String object is required.");
    element = (String)v;
  }

  // Get and set the left child
  public BSTNode left() { return left; }
  public void setLeft(BSTNode p) { left = p; }

  // Get and set the right child
  public BSTNode right() { return right; }
  public void setRight(BSTNode p) { right = p; }

  // return TRUE if a leaf node, FALSE otherwise
  public boolean isLeaf() { return (left == null) && (right == null); }
}