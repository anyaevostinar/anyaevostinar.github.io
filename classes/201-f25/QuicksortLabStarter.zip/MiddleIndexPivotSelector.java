/**
 * @author Anya Vostinar
 * Note this isn't a particularly elegant implementation and instead
 * focuses on being clear and easy to understand.
 */
public class MiddleIndexPivotSelector implements PivotSelector {

    /**
     * Chooses the pivot index as the median of the first, middle, and last elements of the array.
     * @param array the overall array being sorted
     * @param first the index of the first element of the subarray being sorted
     * @param last the index of the last element of the subarray being sorted
     * @return the middle index
     */
    public int choosePivotIndex(int[] array, int first, int lastSubarray) {
        return (first + lastSubarray)/2;
    }
}