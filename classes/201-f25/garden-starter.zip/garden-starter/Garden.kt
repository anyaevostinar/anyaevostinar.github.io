import Plant
import Carrot

/**
 * Garden is a simulation of an actual garden that instantiates plants, waters them,
 * and displays them.  (Add details if you change things about the class.)
 * Look at the lab description for details about what to do with the Garden class.
 */
class Garden {
    // TODO: fill in this class as an extension
}

fun main() {
    // TODO: create a List of Plants and simulate their lives!
}