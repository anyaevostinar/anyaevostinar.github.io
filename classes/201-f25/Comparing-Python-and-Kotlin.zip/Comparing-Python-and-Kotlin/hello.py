"""
   hello.py
   Jeff Ondich, 2013-01-04
   Anna Rafferty

   Modified by Tanya Amert for Spring 2025

   Intended as the Python half of parallel examples in Python and
   Kotlin. See Hello.kt.
"""

print("Hello, world!")