/*
 * Hello.kt
 * Tanya Amert, 2025-03-31
 * Based on Hello.java by Jeff Ondich
 *
 * Hello world, Kotlin style.
 *
 * This is the Kotlin half of a pair of parallel examples in Python and Kotlin.
 * See hello.py.
 */

fun main() {
    println("Hello, world!")
}