import Graph
import MysteryUnweightedGraphImplementation
import UnweightedGraph


fun getBreadthFirstTraversal(inputGraph : UnweightedGraph, originVertex: Int) : MutableList<Int> {
    var traversalOrder = mutableListOf(originVertex)
    var vertexQueue = mutableListOf(originVertex)
    var visitedVertices = HashMap<Int, Boolean>()
    //Your code here!

    return traversalOrder
}

fun main() 
{

    val test = MysteryUnweightedGraphImplementation(false, 4)
    test.addEdge(0, 3)
    test.addEdge(1, 3)
    test.addEdge(3, 2)
    test.addEdge(1, 2)

    val traversed = getBreadthFirstTraversal(test, 0)
    for(node in traversed) {
        print(node)
        print(", ")
    }
    println()
}