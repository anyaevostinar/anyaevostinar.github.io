class BroomballTeam:
    ''' Class representing a team of BroomballPlayer instances. '''

    def __init__(self, name, city):
        ''' Create empty team. '''
        self.name = name
        self.city = city
        self.players = []
        self.results = []

    def addPlayer(self, player):
        ''' Add given player to team roster. '''
        self.players.append(player)

    def removePlayer(self, player):
        ''' Remove given player from team roster. '''
        self.players.remove(player)

    def recordGame(self, result):
        ''' Add a given result (W/L/T) to team's results list. '''
        self.results.append(result)

    def getWinningPercentage(self):
        ''' Return percentage of results that are a W. '''
        return self.results.count('W') / len(self.results)