class BroomballPlayer:
  ''' Class representing a broomball player. '''

  def __init__(self, name, talent):
    ''' Create new player with given name and talent score. '''
    self.name = name
    self.talent = talent
    self.goalsPerGame = []

  def getName(self):
    ''' Retrieve player's name. '''
    return self.name

  def getTalent(self):
    ''' Retrieve player's talent score (max goals per game). '''
    return self.talent

  def recordGame(self, numGoals):
    ''' Add a new game to player in which they score given number of goals. '''
    self.goalsPerGame.append(numGoals)