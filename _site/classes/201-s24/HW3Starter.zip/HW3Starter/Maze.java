import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
* Insert Documentation here!
*
*/
public class Maze { 
    //Number of rows in the maze.
    private int numRows;
    
    //Number of columns in the maze.
    private int numColumns;
    
    //Grid coordinates for the starting maze square
    private int startRow;
    private int startColumn;
    
    //Grid coordinates for the final maze square
    private int finishRow;
    private int finishColumn;
    
    //A double array of the MazeSquares in the maze
    MazeSquare[][] squares;
    
    /**
     * Creates an empty maze with no squares.
     */
    public Maze() {
    } 
    
        /**
     * Insert documentation here!
     * 
     */
    public boolean load(String fileName) { 
      File inputFile = new File(fileName);
      Scanner scanner = null;
      try {
        scanner = new Scanner(inputFile);
      } catch (FileNotFoundException e) {
        System.err.println(e);
        System.exit(1);
      }

      numRows = Integer.parseInt(scanner.next());
      numColumns = Integer.parseInt(scanner.next());
      squares = new MazeSquare[numRows][numColumns];
      startRow = Integer.parseInt(scanner.next());
      startColumn = Integer.parseInt(scanner.next());
      finishRow = Integer.parseInt(scanner.next());
      finishColumn = Integer.parseInt(scanner.next());

      for(int i=0; i<numRows; i++){
        String linecode = scanner.next();
        for (int j=0; j<numColumns; j++) {
          String code = linecode.substring(j,j+1);
          if(code.equals("7")){
            squares[i][j] = new MazeSquare(true, true, i, j);
          } else if(code.equals("|")) {
            squares[i][j] = new MazeSquare(false, true, i, j);
          } else if(code.equals("_")) {
            squares[i][j] = new MazeSquare(true, false, i, j);
          } else if(code.equals("*")) {
            squares[i][j] = new MazeSquare(false, false, i, j);
          } else {
            return false;
          }
          
        }
      }
      

      return true;
    }  
    
    /**
     * Insert documentation here!
     */
    public void print(boolean solution) {
        //We'll print off each row of squares in turn.
        for(int row = 0; row < numRows; row++) {
            
            //Print each of the lines of text in the row
            for(int charInRow = 0; charInRow < 4; charInRow++) {
                //Need to start with the initial left wall.
                if(charInRow == 0) {
                    System.out.print("+");
                } else {
                    System.out.print("|");
                }
                
                for(int col = 0; col < numColumns; col++) {
                    MazeSquare curSquare = this.getMazeSquare(row, col);
                    if(charInRow == 0) {
                        //We're in the first row of characters for this square - need to print
                        //top wall if necessary.
                        if(curSquare.hasTopWall()) {
                            System.out.print(getTopWallString());
                        } else {
                            System.out.print(getTopOpenString());
                        }
                    } else if(charInRow == 1 || charInRow == 3) {
                        //These are the interior of the square and are unaffected by
                        //the start/final state.
                        if(curSquare.hasRightWall()) {
                            System.out.print(getRightWallString());
                        } else {
                            System.out.print(getOpenWallString());
                        }
                    } else {
                        //We must be in the second row of characters.
                        //This is the row where start/finish should be displayed if relevant
                        
                        //Check if we're in the start or finish state
                        if(startRow == row && startColumn == col) {
                            System.out.print("  S  ");
                        } else if(finishRow == row && finishColumn == col) {
                            System.out.print("  F  ");
                        } else if(curSquare.getSolutionPiece() && solution) {
                          System.out.print("  *  ");
                        } else {
                            System.out.print("     ");
                        }
                        if(curSquare.hasRightWall()) {
                            System.out.print("|");
                        } else {
                            System.out.print(" ");
                        }
                    } 
                }
                
                //Now end the line to start the next
                System.out.print("\n");
            }           
        }
        
        //Finally, we have to print off the bottom of the maze, since that's not explicitly represented
        //by the squares. Printing off the bottom separately means we can think of each row as
        //consisting of four lines of text.
        printFullHorizontalRow(numColumns);
    }
    
    /**
     * Prints the very bottom row of characters for the bottom row of maze squares (which is always walls).
     * numColumns is the number of columns of bottom wall to print.
     */
    private static void printFullHorizontalRow(int numColumns) {
        System.out.print("+");
        for(int row = 0; row < numColumns; row++) {
            //We use getTopWallString() since bottom and top walls are the same.
            System.out.print(getTopWallString());
        }
        System.out.print("\n");
    }
    
    /**
     * Returns a String representing the bottom of a horizontal wall.
     */
    private static String getTopWallString() {
        return "-----+";
    }
    
    /**
     * Returns a String representing the bottom of a square without a
     * horizontal wall.
     */
    private static String getTopOpenString() {
        return "     +";
    }
    
    /**
     * Returns a String representing a left wall (for the interior of the row).
     */
    private static String getRightWallString() {
        return "     |";
    }
    
    /**
     * Returns a String representing no left wall (for the interior of the row).
     */
    private static String getOpenWallString() {
        return "      ";
    }
    
    /**
     * Insert documentation here!
     */
    public MazeSquare getMazeSquare(int row, int col) {
        return squares[row][col];
    }

    
    /**
    * Insert documentation here!
    */
    public Stack<MazeSquare> getSolution() {
      Stack<MazeSquare> solution = new LinkedStack<MazeSquare>();


      return solution;
    }
    
 
    /**
     * Insert documentation here!
     */ 
    public static void main(String[] args) {
      if(args.length == 1) {
        Maze myMaze = new Maze();
        myMaze.load(args[0]);
        myMaze.print(false);
      }
    } 
}