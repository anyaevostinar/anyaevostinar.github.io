import java.util.*;
import java.io.*;

public class PathFinder {
  UnweightedGraph wikiGraph = new MysteryUnweightedGraphImplementation();
  Map<String, Integer> articleVertex = new HashMap<String, Integer>();
  Map<Integer, String> vertexArticle = new HashMap<Integer, String>();
  /**
  * Constructs a PathFinder that represents the graph with nodes (vertices) specified as in
  * nodeFile and edges specified as in edgeFile.
  * @param nodeFile name of the file with the node names
  * @param edgeFile name of the file with the edge names
  */
  public PathFinder(String nodeFile, String edgeFile){
    readNodes(nodeFile);
    readEdges(edgeFile);

  }

  private void readNodes(String nodeFile) {
    File inputFile = new File(nodeFile);
    Scanner scanner = null;
    try {
        scanner = new Scanner(inputFile);
    } catch (FileNotFoundException e) {
        System.err.println(e);
        System.exit(1);
    }

    while(scanner.hasNextLine()) {
      String line = scanner.nextLine();
      if(line.length() > 0 && !line.substring(0,1).equals("#")) {
        Integer nodeNum = wikiGraph.addVertex();
        articleVertex.put(line, nodeNum);
        vertexArticle.put(nodeNum, line);
      }
    }
  }

  private void readEdges(String edgeFile) {
    File inputFile = new File(edgeFile);
    Scanner scanner = null;
    try {
        scanner = new Scanner(inputFile);
    } catch (FileNotFoundException e) {
        System.err.println(e);
        System.exit(1);
    }

    while(scanner.hasNextLine()) {
      String line = scanner.nextLine();
      if(line.length() > 0 && !line.substring(0,1).equals("#")) {
        String[] splitline = line.split("\\s+");
        System.out.println(line);
        String begin = splitline[0];
        String end = splitline[1];
        
        int beginNum = articleVertex.get(begin);
        int endNum = articleVertex.get(end);
        wikiGraph.addEdge(beginNum, endNum);
      }
    }
  }


  /**
  * Insert your documentation!
  */
  public Map<Integer, Integer> breadthFirstSearch(String start) {
    
    //Your code here!

    return new HashMap<Integer, Integer>();
  }
  
  /**
  * Returns a shortest path from node1 to node2, represented as list that has node1 at
  * position 0, node2 in the final position, and the names of each node on the path
  * (in order) in between. If the two nodes are the same, then the "path" is just a
  * single node. If no path exists, returns an empty list.
  * @param node1 name of the starting article node
  * @param node2 name of the ending article node
  * @return list of the names of nodes on the shortest path
  */
  public List<String> getShortestPath(String node1, String node2){
    
    //Your code here!
    
    return new ArrayList<String>();
  }

  /**
  * Your documentation here!
  *
  */
  public String toString() {
    return "";
  }

  public static void main(String[] args) {
    System.out.println("Nothing yet!");
  }
  
}
                  