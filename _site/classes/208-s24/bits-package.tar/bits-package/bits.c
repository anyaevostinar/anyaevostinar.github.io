/*
    bits.c
    Jeff Ondich, 19 January 2022
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "bits.h"

void to_upper(char *s) {
}

void to_lower(char *s) {
}

int middle_bits(int x, int low_bit_index, int high_bit_index) {
    return 0;
}

bool to_utf8(int codepoint, char *utf8_buffer) {
    return false;
}

int from_utf8(char *utf8_buffer) {
    return -1;
}
