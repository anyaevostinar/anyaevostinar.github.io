'''
   hello.py
   Jeff Ondich, 2013-01-04
   Anna Rafferty

   Intended as the Python half of parallel examples in Python and
   Java. See Hello.java.
'''

print('Hello world!')