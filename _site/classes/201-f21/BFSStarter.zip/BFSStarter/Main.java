import java.util.*;

class Main {

  /**
   * Conducts a breadth first traversal of the pr
   * @param inputGraph the graph that should be traversed
   * @param originVertex an integer representing the number of the vertex that the traversal should start at
   * @return a queue with integers showing the order that the vertices were traversed
   */
  public static Queue<Integer> getBreadthFirstTraversal(UnweightedGraph inputGraph, Integer originVertex) {
    Queue<Integer> traversalOrder = new LinkedList<Integer>();
    Queue<Integer> vertexQueue = new LinkedList<Integer>();
    Map<Integer, Boolean> visitedVertices = new HashMap<Integer, Boolean>();

    //Your code here!

    return traversalOrder;
  }


  public static void main(String[] args) {
    UnweightedGraph test = new MysteryUnweightedGraphImplementation(false, 4);
    test.addEdge(0, 3);
    test.addEdge(1, 3);
    test.addEdge(3, 2);
    test.addEdge(1, 2);

    Queue<Integer> traversed = getBreadthFirstTraversal(test, 0);
    for(Integer node : traversed) {
      System.out.print(node + ", ");
    }
    System.out.println();

  }
}